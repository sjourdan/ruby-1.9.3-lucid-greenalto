module Fiddle
  class Function
    # The ABI of the Function.
    attr_reader :abi
  end
end
