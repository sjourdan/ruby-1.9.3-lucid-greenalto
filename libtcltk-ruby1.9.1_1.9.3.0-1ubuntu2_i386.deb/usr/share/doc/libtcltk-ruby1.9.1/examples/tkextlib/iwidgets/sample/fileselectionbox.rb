#!/usr/bin/ruby1.9.1
require 'tk'
require 'tkextlib/iwidgets'

Tk::Iwidgets::Fileselectionbox.new.pack(:padx=>10, :pady=>10,
                                        :fill=>:both, :expand=>true)

Tk.mainloop
