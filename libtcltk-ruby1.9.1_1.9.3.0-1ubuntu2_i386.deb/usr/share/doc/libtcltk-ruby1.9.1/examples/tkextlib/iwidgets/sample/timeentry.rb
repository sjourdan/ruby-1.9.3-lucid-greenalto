#!/usr/bin/ruby1.9.1
require 'tk'
require 'tkextlib/iwidgets'

Tk::Iwidgets::Timeentry.new.pack

Tk.mainloop
