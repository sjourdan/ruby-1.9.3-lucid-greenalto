#!/usr/bin/ruby1.9.1
require 'tk'
require 'tkextlib/iwidgets'

Tk::Iwidgets::Canvasprintdialog.new.activate

Tk.mainloop

