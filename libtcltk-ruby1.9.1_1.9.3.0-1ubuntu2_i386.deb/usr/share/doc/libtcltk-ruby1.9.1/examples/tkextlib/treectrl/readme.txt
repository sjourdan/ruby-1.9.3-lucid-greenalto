The scripts and image files in this directory are based on demo files
of Tcl/Tk's TreeCtrl extention.
