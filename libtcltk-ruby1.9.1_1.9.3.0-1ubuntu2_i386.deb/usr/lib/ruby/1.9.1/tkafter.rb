#
#   tkafter.rb - load tk/after.rb
#
require 'tk/timer'
