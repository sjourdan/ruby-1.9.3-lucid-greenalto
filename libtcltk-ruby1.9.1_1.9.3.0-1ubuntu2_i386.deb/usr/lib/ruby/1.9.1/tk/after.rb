#
#   tk/after.rb : methods for Tcl/Tk after command
#
#   $Id: after.rb 25189 2009-10-02 12:04:37Z akr $
#
require 'tk/timer'
