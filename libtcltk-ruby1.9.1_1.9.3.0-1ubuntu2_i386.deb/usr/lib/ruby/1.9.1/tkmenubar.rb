#
#   tkmenubar.rb - load tk/menubar.rb
#
require 'tk/menubar'
